package com.jarvanmo.nautilus

/***
 * Created by mo on 2018/11/22
 * 冷风如刀，以大地为砧板，视众生为鱼肉。
 * 万里飞雪，将穹苍作烘炉，熔万物为白银。
 **/
internal const val keyPlatform ="platform"
internal const val keyAndroid ="android"
internal const val keyResult ="result"
internal const val keyErrorCode ="errorCode"
internal const val keyErrorMessage ="errorMessage"